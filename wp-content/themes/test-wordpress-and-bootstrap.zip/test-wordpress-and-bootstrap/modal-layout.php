<form class=" " role="form">
    <div class="form-group">
        <label class="sr-only" for="name">Your name</label>
        <input type="text" class="form-control" placeholder="Your name">
    </div><!--form group--->
    <div class="form-group">
        <label class="sr-only" for="email">Your email</label>
        <input type="text" class="form-control" placeholder="Your email">
    </div><!--form group--->
    <div class="form-group">
        <label class="sr-only" for="getIdea">Your idea</label>
        <textarea type="text" class="form-control" placeholder="Your idea" rows="6" ></textarea>
    </div>
    <div>
        <input type="submit" class="btn btn-danger" value="Get quote!">
    </div>
</form>
