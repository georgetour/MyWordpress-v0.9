# Wordpress-Live-Test
Combining Bootstrap with Wordpress and custom theme creation.<br>
- This is a site that people will be able to understand what Wordpress is by enrolling and testing with their own password.
- For some hours they will receive a password so they can test it and see how easy it is to update something in the site without coding.
- Your future customers will love it.
