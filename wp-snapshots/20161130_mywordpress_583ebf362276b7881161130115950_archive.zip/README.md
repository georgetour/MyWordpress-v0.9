#MyWordpress
<br>
- This is a Custom Wordpress theme with Bootstrap. <br>
- Clients will have a demonstration video on how wordpress works and what you they can do with that if I built the site with Wordpress.
